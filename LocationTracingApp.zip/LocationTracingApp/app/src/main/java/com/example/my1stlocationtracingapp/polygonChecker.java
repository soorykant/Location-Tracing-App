package com.example.my1stlocationtracingapp;

import com.google.android.gms.maps.model.LatLng;

import java.util.List;

public class polygonChecker {

    public boolean Contains(LatLng currentLocation, List<LatLng> polygon){

        if(currentLocation == null)
            return false;

        LatLng lastPoint = polygon.get(polygon.size()-1);
        boolean isInside = false;
        double x = currentLocation.longitude;

        for(LatLng point:polygon){

            double x1 = lastPoint.longitude;
            double x2 = point.longitude;
            double dx = x2 - x1;

            if(Math.abs(dx)>180.0){
                if(x>0){
                    while(x1<0)
                        x1+=360;
                    while(x2<0)
                        x2+=360;
                } else{
                    while(x1<0)
                        x1-=360;
                    while(x2<0)
                        x2-=360;
                }
                dx = x2 - x1;
            }

            if((x1<= x && x2>x) || (x1>=x && x2<x)){

                double grad = (point.latitude - lastPoint.latitude)/dx;
                double intersectAtLat = lastPoint.latitude + (x-x1)*grad;

                if(intersectAtLat>currentLocation.latitude)
                    isInside = !isInside;

            }
            lastPoint = point;
        }
        return isInside;
    }
}
