package com.example.my1stlocationtracingapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.RemoteInput;

public class viewDetails extends AppCompatActivity {

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_details);
        TextView t = (TextView)findViewById(R.id.textViewResult);
        t.setText(getMessageText(this.getIntent()));
    }

    private CharSequence getMessageText(Intent intent){
        Bundle remoteInput = RemoteInput.getResultsFromIntent(intent);
        if(remoteInput != null)
            return remoteInput.getCharSequence("map_key1");
        else
            return null;
    }
}
