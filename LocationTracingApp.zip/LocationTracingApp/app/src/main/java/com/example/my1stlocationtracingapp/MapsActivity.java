package com.example.my1stlocationtracingapp;

import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import androidx.core.app.RemoteInput;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolygonOptions;

import java.util.ArrayList;
import java.util.List;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    public static String CHANNEL_ID = "mapChannel";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        checkGPSEnables();
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @RequiresApi(api = Build.VERSION_CODES.KITKAT_WATCH)
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        OtherFunctions otherFunObj = new OtherFunctions(this);
        if(otherFunObj.CheckPermission(Manifest.permission.ACCESS_FINE_LOCATION, getApplicationContext(), this)){
            Toast.makeText(this, "GPS Permissions Allowed", Toast.LENGTH_LONG).show();
            try{
                mMap.setMyLocationEnabled(true);
                mMap.getUiSettings().setZoomControlsEnabled(true);
                LatLng latlng = new LatLng(26.509802, 80.228558);
                mMap.addMarker(new MarkerOptions().position(latlng).title("Hall 5, IITK"));
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latlng, 17));

                //Circular GeoFence
                /*
                Circle circ = mMap.addCircle(new CircleOptions().center(latlng).radius(100).strokeColor(Color.BLACK));
                LatLng newLocation = new LatLng(22.0060217, 82.2785571);
                float[] distance = new float[1];
                Location.distanceBetween(newLocation.latitude, newLocation.longitude, latlng.latitude, latlng.longitude, distance);
                if(distance[0] > circ.getRadius()){
                    Toast.makeText(getApplicationContext(), "Distance: "+distance[0]+" Location is outside the circle.", Toast.LENGTH_LONG).show();
                } else{
                    Toast.makeText(getApplicationContext(), "Distance: "+distance[0]+" Location is within the circle", Toast.LENGTH_LONG).show();
                }
                 */

                LatLng newLocation = new LatLng(26.508824, 80.228302);
                mMap.addMarker(new MarkerOptions().position(newLocation).title("I Block, Hall 5"));

                LatLng l1 = new LatLng(26.511473, 80.229038);
                LatLng l2 = new LatLng(26.509532, 80.232270);
                LatLng l3 = new LatLng(26.506839, 80.231590);
                LatLng l4 = new LatLng(26.507600, 80.224764);
                LatLng l5 = new LatLng(26.511225, 80.225742);

                List<LatLng> polygonEdges = new ArrayList<LatLng>();

                polygonEdges.add(l1);
                polygonEdges.add(l2);
                polygonEdges.add(l3);
                polygonEdges.add(l4);
                polygonEdges.add(l5);

                mMap.addPolygon(new PolygonOptions().addAll(polygonEdges).strokeColor(Color.BLACK));

                polygonChecker PolCheckObj = new polygonChecker();
                boolean result = PolCheckObj.Contains(newLocation, polygonEdges);

                createChannelId();

                Intent viewDetails = new Intent(this, com.example.my1stlocationtracingapp.viewDetails.class);
                PendingIntent vIntent = PendingIntent.getActivity(this, 0, viewDetails, 0);

                Intent destination = new Intent(this, com.example.my1stlocationtracingapp.Destination.class);
                PendingIntent dIntent = PendingIntent.getActivity(this, 0, destination, 0);

                RemoteInput remoteInput = new RemoteInput.Builder("map_key1").setLabel("Typing...").build();

                NotificationCompat.Action action = new NotificationCompat.Action.Builder
                        (R.drawable.ic_launcher_background, "Reply", vIntent)
                        .addRemoteInput(remoteInput).build();

                if(result){
                    NotificationCompat.Builder NoteBuilder = new NotificationCompat.Builder(this, CHANNEL_ID)
                            .setSmallIcon(R.drawable.ic_launcher_background)
                            .setContentTitle("Geo Fence Notifications")
                            .setContentText("You have entered the GeoFence")
                            .setChannelId(CHANNEL_ID)
                            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                            .setContentIntent(vIntent)
                            .setAutoCancel(true)
                            .addAction(R.drawable.ic_launcher_background, "Set Destination", dIntent)
                            .addAction(action);

                    NotificationManager NoteManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                    NoteManager.notify(0, NoteBuilder.build());
                } else{
                    NotificationCompat.Builder NoteBuilder = new NotificationCompat.Builder(this, CHANNEL_ID)
                            .setSmallIcon(R.drawable.ic_launcher_background)
                            .setContentTitle("Geo Fence Notifications")
                            .setContentText("You have exited the GeoFence")
                            .setChannelId(CHANNEL_ID)
                            .setPriority(NotificationCompat.PRIORITY_DEFAULT);
                    NotificationManager NoteManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                    NoteManager.notify(0, NoteBuilder.build());
                }

            }
            catch (SecurityException e){
                Log.println(Log.ERROR, "Set My Location Error", e.getMessage());
            }
        }
        else{
            Toast.makeText(this, "GPS Permissions Denied", Toast.LENGTH_LONG).show();
            otherFunObj.requestPermission(Manifest.permission.ACCESS_FINE_LOCATION, 1, getApplicationContext(), this);
        }
    }

    public void createChannelId(){

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            CharSequence name = "MapChannel_For_SweetHome";
            String description = "Channel Description";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            channel.enableVibration(true);
            channel.enableLights(true);
            NotificationManager NoteMan = getSystemService(NotificationManager.class);
            NoteMan.createNotificationChannel(channel);
        }
    }


    public void checkGPSEnables(){

        int locationMode = Settings.Secure.getInt(
                getContentResolver(),
                Settings.Secure.LOCATION_MODE,
                Settings.Secure.LOCATION_MODE_OFF
        );

        OtherFunctions otherFunObj = new OtherFunctions(this);
        if(locationMode == Settings.Secure.LOCATION_MODE_OFF){
            //prompt the dialog box for GPS enabling
            otherFunObj.ShowSettingsAlert();
        }
    }
}