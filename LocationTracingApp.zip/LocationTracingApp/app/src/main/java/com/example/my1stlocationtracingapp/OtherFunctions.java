package com.example.my1stlocationtracingapp;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class OtherFunctions extends AppCompatActivity {
    public static Context currentContex;

    public OtherFunctions(Context con){
        currentContex = con;
    }

    public void ShowSettingsAlert(){
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(currentContex);
        alertDialog.setTitle("GPS Settings");
        alertDialog.setMessage("GPS is not anabled. Do you want to open settings menu?");

        alertDialog.setPositiveButton("Settings", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                currentContex.startActivity(intent);
            }
        });

        alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        alertDialog.show();
    }

    public static boolean CheckPermission(String strPermission, Context _c, Activity _a){
        int result = ContextCompat.checkSelfPermission(_c, strPermission);
        if(result == PackageManager.PERMISSION_GRANTED)
            return true;
        else
            return false;
    }

    public static void requestPermission(String strPermission, int perCode, Context _c, Activity _a){
        if(ActivityCompat.shouldShowRequestPermissionRationale(_a, strPermission))
            Toast.makeText(currentContex, "Please allow GPS permission", Toast.LENGTH_LONG).show();
        else
            ActivityCompat.requestPermissions(_a, new String[] {strPermission}, perCode);
    }

    private static final int PERMISSION_REQUEST_CODE_LOCATION = 1;

    public void onRequestPermissionResult(int requestCode, String permissions[], int[] grantResult){
        switch (requestCode){
            case PERMISSION_REQUEST_CODE_LOCATION:
                if(grantResult.length>0 && grantResult[0] == PackageManager.PERMISSION_GRANTED){
                    //fetch the current location data.
                }
                else{
                    //requested permission has been denied.
                }
                break;
        }
    }

}
